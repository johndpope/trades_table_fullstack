const connection = require('./connection-wrapper')

async function getAllTrades() {
    let sql = `SELECT * FROM stocks_table.dash_202101`;
    try {
        let allTrades = await connection.execute(sql);
        return allTrades;
    }
    catch (err) {
        throw new ServerError(ErrorType.GENERAL_ERROR, sql, err);
    }
}


module.exports = {
    getAllTrades
};