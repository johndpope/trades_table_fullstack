const express = require('express')
const router = express.Router()
const tradeLogic = require("../logic/trade-logic.js")

router.get("/", async (req, res, next) => {
    try {
        console.log("connection made with client");
        const resultDash= await tradeLogic.getAllTrades();
        res.json(resultDash);
    }
    catch (error) {
        return next(error);
    }
})




module.exports = router