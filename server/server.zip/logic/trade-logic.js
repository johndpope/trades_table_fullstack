const  tradesDao = require("../dao/trade-dao.js")





async function getAllTrades() {
    return await tradesDao.getAllTrades();
}






module.exports = { getAllTrades}